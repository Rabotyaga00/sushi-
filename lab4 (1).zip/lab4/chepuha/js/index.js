let quest = ["Кто?", "Где?", "С кем?", "Что делали?", "Зачем?", "Чем дело закончилось?"]
step = 0;
let questNode = document.querySelector(`#question`);
let input = document.querySelector(`#input`);
questNode.innerHTML = quest[0];
document.querySelector(`#submit`).addEventListener(`click`, sumbit)

function sumbit(){
    step += 1;
   questNode.innerHTML = quest[step];
   document.querySelector(`#answ`).innerHTML += input.value + " ";
   console.log(step);
   input.value = '';
   if (step == quest.length) {
    document.querySelector(`#answ`).style.display = `block`;
    questNode.innerHTML = `КОнец!!!`;
    input.disabled = true;
    document.querySelector(`#submit`).disabled = true;
   }
}

document.addEventListener(`keydown`, enter);


function enter(evt){
    if (evt.key == "Enter"){
        document.querySelector(`#submit`).click();
        evt.preventDefault();
    }
    
}