let dInput = document.querySelector(`#d`);
let fInput = document.querySelector(`#f`);

let dToFButton = document.querySelector(`#d-to-f`);
let fToDButton = document.querySelector(`#f-to-d`);

dToFButton.addEventListener(`click`, Celsius);
fToDButton.addEventListener(`click`, Fahranheit);

function Celsius(){
    fInput.value = Math.round((dInput.value * (9/5) + 32) * 100) / 100;
}

function Fahranheit(){
    dInput.value = Math.round(((fInput.value- 32) * (5/9))  * 100) / 100;
}
