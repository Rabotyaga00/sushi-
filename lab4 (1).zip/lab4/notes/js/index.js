let template = `
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Название</h5>
    <h6 class="card-categoty mb-2">Категория</h6>
    <p class="card-text">Содержание</p>
  </div>
  <div class="card-footer text-muted">
    Дата
  </div>
</div>
`;
let number = 0;
let saveButton = document.querySelector(`#save`);
let textInput = document.querySelector(`#text`);
let titleInput = document.querySelector(`#title`);
let categoryInput = document.querySelector(`#category`);
let dateInput = document.querySelector(`#date`);
let notesNode = document.querySelector(`#notes`);
let title = "Заголовок";
let categoty = "Учеба";
let text = "серединка";


saveButton.addEventListener(`click`, addNote);

function addNote(){
  console.log(number);
  notesNode.innerHTML += template;
  document.querySelector(`.card-title:nth-last-child(1)`).innerHTML = titleInput.value;
  console.log(document.querySelectorAll(`.card-title:nth-last-child(1)`).innerHTML);
  document.querySelectorAll(`.card-categoty:nth-child(${number})`).innerHTML = categoryInput.value;
  // if (categoryInput.value == "Учеба") {
  //   document.querySelectorAll(`.card:nth-child(${number})`).classList.add(`study`);
  // } else if (categoryInput.value == "Важное") {
  //   document.querySelectorAll(`.card:nth-child(${number})`).classList.add(`important`)
  // }
  document.querySelectorAll(`.card-text:nth-child(${number})`).innerHTML = textInput.value;
  document.querySelectorAll(`.card-footer:nth-child(${number})`).innerHTML = dateInput.value;
  number++;
}