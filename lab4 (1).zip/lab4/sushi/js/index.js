console.log(alert(`ВЭРЭВКИН!!!!`))
let promo = `VEREVKIN2005`;


document.querySelector(`#login-button`).addEventListener(`click`, sumbit());

function sumbit(){
    return function(){
        let promoCheck = document.querySelector(`#promocode`).value;
        if(promoCheck == promo){
            document.querySelector(`.form-control`).classList.remove(`is-invalid`);
            document.querySelector(`.form-control`).classList.add(`is-valid`);
            document.querySelector(`.valid-feedback`).innerHTML = `Correct`; 
            document.querySelector(`#sushi`).classList.remove(`d-none`);   
            document.querySelector(`#sushi`).style.display = `block`;
            return true;
        } else {
            document.querySelector(`.form-control`).classList.remove(`is-valid`);
            document.querySelector(`.form-control`).classList.add(`is-invalid`);
            document.querySelector(`.invalid-feedback`).innerHTML = `Incorrect`;
            document.querySelector(`#sushi`).style.display = `none`;
            return false;
            
        }
    }
}